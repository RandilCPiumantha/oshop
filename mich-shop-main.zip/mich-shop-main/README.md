# MichShop

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 12.1.2.

# Setup
> npm install

# Note
- Did not implement angular-4-data-table
- Changed ng-bootstrap to ngx-bootstrap, due to some dependency error

# Check site
- https://mich-shop.firebaseapp.com/