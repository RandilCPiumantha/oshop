export interface ICategories {
    name: string;
}